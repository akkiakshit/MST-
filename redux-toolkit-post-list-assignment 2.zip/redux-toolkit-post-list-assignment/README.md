# Redux Toolkit Post List

## Q2 - Create a Post List using Redux Toolkit

This basic React + Redux Toolkit project implements all required functionality:

1. A `postsSlice` with an `addPost` reducer.
2. An input field and **Add** button that dispatch `addPost`.
3. All posts are displayed using `useSelector`.
4. Total post count is shown at the top.

## Run the project

Open the project folder in VS Code and run:

```bash
npm install
npm run dev
```

Then open the local URL shown by Vite.

## Main files

- `src/app/store.js` - Redux store setup
- `src/features/posts/postsSlice.js` - posts slice and `addPost` reducer
- `src/App.jsx` - input, dispatch, post list, and count
- `src/main.jsx` - Redux Provider setup
- `src/App.css` - basic styling
